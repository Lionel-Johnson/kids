<?php 
/*include_once('conn.php');*/
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtouriste";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
} 
$mess='';
$mess2='';
$mess3='';
	$an=@$_POST['annee'];
?>
<!-- Created by TopStyle Trial - www.topstyle4.com -->
<!DOCTYPE html>
<html>
<head>
	<title>chcode_appli</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>

<body>
	<div align="center">
	<a href="index.php">ENREGISTREMENT</a><br><br>
	<?php 
	print'<h2>NOMBRE DE TOURISTES PAR NATIONALITE ET PAR AN :</h2>';
	 
	     $rq=mysqli_query($conn,"select nationalite,count(id) as nombre,annee from touriste group by nationalite,annee order by annee desc ");
	    
	print'<table border="1" class="tab"><tr><th>NATIONALITE</th><th>NOMBRE</th><th>ANNEE</th></tr>';
	     while($rst=mysqli_fetch_assoc($rq)){
	     
	        $nationalite=$rst['nationalite'];
	        $nombre=$rst['nombre'];
	        $annee=$rst['annee'];
	         print"<tr>";
	         echo"<td>$nationalite</td>";
	         echo"<td>$nombre</td>";
	         echo"<td>$annee</td>";
	         print"</tr>";   
	     }
	   print'</table>';
	?>
	<br>
		<h2>NOMBRE DE TOURISTES PAR NATIONALITE ET PAR MOIS :</h2>
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST" >
	<tr><td><input type="number" name="annee" min="1000" value="<?php print $an;?>" placeholder="ANNEE" class="champ" size="25"></td>
	<td><input type="submit" name="btok" value="OK"  ></td></tr>
	</form>
	<br>
	<?php 

	if(isset($_POST['btok'])){
	/*select nationalite,count(id) as nombre,mois,annee from touriste where annee='"+tfannee.getText()+"'  group by nationalite,mois */
	     $rq=mysqli_query($conn,"select nationalite,count(id) as nombre,mois,annee from touriste where annee='$an'  group by nationalite,mois ");
	    
	print'<table border="1" class="tab"><tr><th>NATIONALITE</th><th>NOMBRE</th><th>MOIS</th><th>ANNEE</th></tr>';
	     while($rst=mysqli_fetch_assoc($rq)){
	     
	        $nationalite=$rst['nationalite'];
	        $nombre=$rst['nombre'];
	        $mois=$rst['mois'];
	        $annee=$rst['annee'];
	         print"<tr>";
	         echo"<td>$nationalite</td>";
	         echo"<td>$nombre</td>";
	         echo"<td>$mois</td>";
	         echo"<td>$annee</td>";
	         print"</tr>";   
	     }
	   print'</table>';
	   }
	?>
	</div>
</body>
</html>