<?php 
/*include_once('conn.php');*/
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtouriste";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
} 
$mess='';
$mess2='';
$mess3='';
?>

<?php 
$nump=@$_POST['nump'];
$nom=@$_POST['nom'];
$prenom=@$_POST['prenom'];
$natio=@$_POST['nationalite'];
$mois=@$_POST['mois'];
$an=@$_POST['annee'];
//inserer
if(isset($_POST['boutadd'])&&!empty($nump)){
$sql=mysqli_query($conn,"insert into touriste(numpass,nom,prenom,nationalite,mois,annee) 
values('$nump','$nom','$prenom','$natio','$mois','$an')");
if($sql){
$mess="<br><b class='succes'>INSERTION REUSSIE !</b>";

}
else
$mess="<br><b class='erreur'>Erreur d'insertion !</b>";
}

?>
<?php 

//suppréssion
if(isset($_POST['boutsupp'])&&!empty($nump)){
$sql=mysqli_query($conn,"delete from touriste where numpass='$nump'");
if($sql){
$mess="<br><b class='succes'>SUPPRESSION REUSSIE !</b>";

}
else
$mess="<br><b class='erreur'>Impossible de supprimer !</b>";
}

?>
<!-- Created by TopStyle Trial - www.topstyle4.com -->
<!DOCTYPE html>
<html>
<head>
	<title>chcode_appli</title>
  
	<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>

<body>
	<div align="center">
	<a href="requetes.php">REQUETES</a><br><br>
	 <h2>ENREGISTREMENT DES TOURISTES A L'ARRIVEE :</h2>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST" >
  <table align="">
  
     <tr ><td></td><td> <?php print $mess;?></td></tr>
    <tr><td></td><td><strong >NUMERO PASSEPORT :</strong></td></tr>
   <tr><td></td><td><input type="text" name="nump" class="champ" size="25"  ></td></tr>
   <tr><td></td><td><strong>NOM :</strong></td></tr>
   <tr><td></td><td><input type="text" name="nom" class="champ" size="25"></td></tr>
   <tr><td></td><td><strong>PRENOM :</strong></td></tr>
   <tr><td></td><td><input type="text" name="prenom" class="champ" size="25"></td></tr>
   <tr><td></td><td><strong>NATIONALITE :</strong></td></tr>
   <tr><td></td><td><input type="text" name="nationalite" class="champ" size="25"></td></tr>
   <tr><td></td><td><b>MOIS :</b></td></tr>
	<tr><td></td><td><select name="mois" id="mois"  >
         <option  value="Janvier">Janvier</option>
        <option  value="Fevrier">Fevrier</option>
         <option  value="Mars">Mars</option>
        <option  value="Avril">Avril</option>
        <option  value="Mai">Mai</option>
        <option  value="Juin">Juin</option>
        <option  value="Juillet">Juillet</option>
        <option  value="Aout">Aout</option>
        <option  value="Septembre">Septembre</option>
        <option  value="Octobre">Octobre</option>
        <option  value="Novembre">Novembre</option>
        <option  value="Decembre">Decembre</option>
     </select></td></tr>
   <tr><td></td><td><strong>ANNEE :</strong></td></tr>
   <tr><td></td><td><input type="number" name="annee" min="1000" value="2020" class="champ" size="25"></td></tr>
      <tr><td></td><td><input type="submit" name="boutadd" value="Enregistrer" class="bouton" ></td></tr>
       <tr><td></td><td><input type="submit" name="boutsupp" value="Supprimer" class="bouton" ></td></tr>
  
  </table>
  </form>
  <br>
  <?php 
	
	 
	     $rq=mysqli_query($conn,"select numpass,nom,prenom,nationalite,mois,annee from touriste order by id desc limit 400 offset 0 ");
	    
	print'<table border="1" class="tab"><tr><th>NUMERO</th><th>NOM</th><th>PRENOM</th><th>NATIONALITE</th><th>MOIS</th><th>ANNEE</th></tr>';
	     while($rst=mysqli_fetch_assoc($rq)){
	     
	        $numero=$rst['numpass'];
	        $nom=$rst['nom'];
	        $prenom=$rst['prenom'];
	        $nationalite=$rst['nationalite'];
	        $mois=$rst['mois'];
	        $annee=$rst['annee'];
	         print"<tr>";
	         echo"<td>$numero</td>";
	         echo"<td>$nom</td>";
	         echo"<td>$prenom</td>";
	         echo"<td>$nationalite</td>";
	         echo"<td>$mois</td>";
	         echo"<td>$annee</td>";
	         
	        
	         print"</tr>";   
	     }
	   print'</table>';
	?>
	   
	</div>
</body>
</html>