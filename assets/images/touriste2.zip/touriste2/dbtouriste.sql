-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Jeu 06 Août 2020 à 13:21
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `dbtouriste`
--

-- --------------------------------------------------------

--
-- Structure de la table `touriste`
--

CREATE TABLE IF NOT EXISTS `touriste` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `numpass` varchar(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `nationalite` varchar(50) NOT NULL,
  `mois` varchar(15) NOT NULL,
  `annee` smallint(6) NOT NULL,
  PRIMARY KEY (`id`,`numpass`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `touriste`
--

INSERT INTO `touriste` (`id`, `numpass`, `nom`, `prenom`, `nationalite`, `mois`, `annee`) VALUES
(1, '23J45T', 'DUPOND', 'JEAN FELIX', 'Française', 'Fevrier', 2020),
(2, '56G12A', 'BILLY', 'PATRICK', 'Américaine', 'Fevrier', 2020),
(4, '44J33C', 'BAHI', 'JOCELAIN', 'Ivoirienne', 'Fevrier', 2020),
(5, '21H78K', 'PHILIP', 'ARNAUD', 'Française', 'Fevrier', 2020),
(6, '66R21A', 'KOULIBALY', 'DAOUD', 'Ivoirienne', 'Fevrier', 2020),
(7, '12S43Z', 'OYONO', 'GILCHRIS', 'Camérounaise', 'Fevrier', 2020),
(8, '45A34S', 'FRANCIS', 'CHARLE', 'Française', 'Mars', 2020),
(9, '14D56J', 'AKAKPO', 'ROMARIC', 'Togolaise', 'Fevrier', 2020),
(10, '78S55H', 'ALICE', 'JUDITH', 'Togolaise', 'Mars', 2021),
(11, '57U90F', 'THOMAS', 'BRUNO', 'Togolaise', 'Fevrier', 2021),
(12, '84V09G', 'TADJO', 'FELIX', 'Camérounaise', 'Avril', 2021),
(13, '89Y12T', 'KOONG', 'LEE', 'Chinoise', 'Mars', 2021),
(14, '89F52T', 'BRANDON', 'YUN', 'Chinoise', 'Mars', 2021),
(15, '13F89H', 'TOUNDJI', 'LAURENT', 'Camérounaise', 'Avril', 2021),
(16, '56G67B', 'LILIANE', 'OLGA', 'Française', 'Avril', 2021);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
