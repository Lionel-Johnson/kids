package diviseurs_java;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Fenetre extends JFrame{
	JTextField TFnbr1;
	JLabel labelrs1,labeltitre,lbnombre1;
JTextArea jta;
JScrollPane spn;
	JButton bt;
	public Fenetre(){
		this.setTitle("chcode_appli");
		this.setSize(600, 300);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		//pn.setBackground(Color.gray);
		add(pn);
		lbnombre1=new JLabel("Entrez un nombre entier :");
		lbnombre1.setBounds(10,60,180,25);
		lbnombre1.setFont(new Font("Arial",Font.BOLD,13));
		pn.add(lbnombre1);
		
		TFnbr1=new JTextField();
		TFnbr1.setBounds(190,60,100,25);
		pn.add(TFnbr1);
		
		labeltitre=new JLabel("Citer tous les diviseurs d'un nombre entier naturel :");
		labeltitre.setBounds(10,10,600,25);
		labeltitre.setFont(new Font("Arial",Font.BOLD,13));
		labeltitre.setForeground(Color.black);
		pn.add(labeltitre);
		
		labelrs1=new JLabel("");
		labelrs1.setBounds(10,160,600,25);
		labelrs1.setFont(new Font("Arial",Font.BOLD,14));
		labelrs1.setForeground(Color.blue);
		pn.add(labelrs1);
		
		 jta=new JTextArea("");
		
		spn=new JScrollPane(jta);
		spn.setBounds(10,190,560,50);
		pn.add(spn);
		
		bt=new JButton("CHERCHER");
		bt.setBounds(80,110,120,25);
		bt.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
			String a=TFnbr1.getText(),mess="";
			
		int a2;
		if(!a.equals("")&&isNumber(a)){
 a2=Integer.valueOf(a).intValue();	
  labelrs1.setText("Voici tous les diviseurs de "+a+" :"); 
  for(int i=1;i<=a2;i++){
	  if(a2%i==0){
		  mess=mess+i+" ; ";
	  }
	}
 
  jta.setText(mess); 
  if(a2==0){
	  jta.setText(""); 
	  labelrs1.setText("Tous les nombres entiers sont les diviseurs de "+a); 
  }
  if(a2==1){
	  jta.setText("1"); 
	  labelrs1.setText(a+" a un seul diviseur : "); 
  }
		} //  
			}
		});
		pn.add(bt);
	}
	//fonction pour v�rifier si une valeur entr�e est num�rique
		public boolean isNumber(String text){
			boolean nombre=false;
			if(!(Integer.valueOf(text).intValue()>=0)){
				nombre=false;
			}
			else{
				nombre=true;
			}
			return nombre;
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fenetre fn=new Fenetre();
		fn.setVisible(true);
		/*Code �crit le 22/01/2021 � N'djam�na au Tchad par TARGOTO CHRISTIAN
		 * Contact: ct@chrislink.net / 23560316682
		 * */
	}

}

