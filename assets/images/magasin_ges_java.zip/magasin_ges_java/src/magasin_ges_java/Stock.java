package magasin_ges_java;
/*Code Java SE �crit du 24 au 26 Avril 2021 � N'djam�na au Tchad par TARGOTO Christian
 * Contact: 23560316682 / ct@chrislink.net */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Stock extends JFrame {
	Statement st;
	Conneccion con=new Conneccion();
	ResultSet rst;
	JTable table,table2,table3;
	JScrollPane scroll,scroll2,scroll3;
	JButton btstock_prod,btstock_prod_date,btstock_mag_prod,btstock_mag_prod_date,btactu;
	public Stock(){
		 this.setTitle("chcode_appli");
	 		this.setSize(900,500);
	 		this.setLocationRelativeTo(null);
	 		this.setResizable(false);
	 		JPanel pn=new JPanel();
	 		pn.setLayout(null);
	 		add(pn);
	 		pn.setBackground(new Color(150,200,240));
	 		
	 		//bouton pour afficher la quantit� en stock des produits (regroupement par nom produit)
			btstock_prod=new JButton("Quantit� en stock par produit");
			btstock_prod.setBounds(300,20,200,25);
			btstock_prod.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ev){
					DefaultTableModel df2=new  DefaultTableModel();
					  init2();
					  pn.add(scroll2);
					 df2.addColumn("Nom produit");
					 df2.addColumn("Quantit� en stock");
					 table2.setModel(df2);
					 
					 String req2="select nom_prod,sum(qte_prod) as qte_stock FROM v_stock1  group by nom_prod";
					 try{
						 st=con.laConnection().createStatement();
						 rst=st.executeQuery(req2);
						 while(rst.next()){
							 df2.addRow(new Object[]{
			rst.getString("nom_prod"),rst.getString("qte_stock")
									 });
							 
						 }
						 
							 
						 }
						 
					 catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
					    }
				}
			});
			pn.add(btstock_prod);
			//bouton pour afficher la quantit� en stock des produits (regroupement par nom produit et date d'expiration)
			btstock_prod_date=new JButton("Quantit� en stock par produit et par date d'expiration");
			btstock_prod_date.setBounds(300,60,340,25);
			btstock_prod_date.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ev){
					DefaultTableModel df2=new  DefaultTableModel();
					  init2();
					  pn.add(scroll2);
					 df2.addColumn("Nom produit");
					 df2.addColumn("Quantit� en stock");
					 df2.addColumn("Date d'expiration");
					 table2.setModel(df2);
					 
					 String req2="select nom_prod,sum(qte_prod) as qte_stock,date_exp FROM v_stock1 group by nom_prod,date_exp";
					 try{
						 st=con.laConnection().createStatement();
						 rst=st.executeQuery(req2);
						 while(rst.next()){
							 df2.addRow(new Object[]{
			rst.getString("nom_prod"),rst.getString("qte_stock"),rst.getString("date_exp")
									 });
							 
						 }
						 
							 
						 }
						 
					 catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
					    }
				}
			});
			pn.add(btstock_prod_date);
			//bouton pour afficher la quantit� en stock des produits (regroupement par numero magasin et par nom produit)
			btstock_mag_prod=new JButton("Quantit� en stock par magasin et par produit");
			btstock_mag_prod.setBounds(300,100,340,25);
			btstock_mag_prod.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ev){
					DefaultTableModel df2=new  DefaultTableModel();
					  init2();
					  pn.add(scroll2);
					 df2.addColumn("Nom produit");
					 df2.addColumn("Quantit� en stock");
					 df2.addColumn("Num�ro magasin");
					 table2.setModel(df2);
					 
					 String req2="select nom_prod,sum(qte_prod) as qte_stock,mag_num FROM v_stock1 group by mag_num,nom_prod";
					 try{
						 st=con.laConnection().createStatement();
						 rst=st.executeQuery(req2);
						 while(rst.next()){
							 df2.addRow(new Object[]{
			rst.getString("nom_prod"),rst.getString("qte_stock"),rst.getString("mag_num")
									 });
							 
						 }
						 
							 
						 }
						 
					 catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
					    }
				}
			});
			pn.add(btstock_mag_prod);

			//bouton pour afficher la quantit� en stock des produits (regroupement par numero magasin par nom produit et par date d'expiration)
					
					btstock_mag_prod_date=new JButton("Quantit� en stock par magasin par produit et par date d'expiration");
					btstock_mag_prod_date.setBounds(300,140,420,25);
					btstock_mag_prod_date.addActionListener(new ActionListener(){
						public void actionPerformed(ActionEvent ev){
							DefaultTableModel df2=new  DefaultTableModel();
							  init2();
							  pn.add(scroll2);
							 df2.addColumn("Nom produit");
							 df2.addColumn("Quantit� en stock");
							 df2.addColumn("Num�ro magasin");
							 df2.addColumn("Date d'expiration");
							 table2.setModel(df2);
							 
							 String req2="select nom_prod,sum(qte_prod) as qte_stock,mag_num,date_exp FROM v_stock1 group by mag_num,nom_prod,date_exp";
							 try{
								 st=con.laConnection().createStatement();
								 rst=st.executeQuery(req2);
								 while(rst.next()){
									 df2.addRow(new Object[]{
					rst.getString("nom_prod"),rst.getString("qte_stock"),rst.getString("mag_num"),rst.getString("date_exp")
											 });
									 
								 } 
								}
								 
							 catch(SQLException ex){
							    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
							    }
						}
					});
					pn.add(btstock_mag_prod_date);
					//bouton pour actualiser la fenetre
					btactu=new JButton("ACTUALISER");
					btactu.setBounds(700,20,120,25);
					btactu.addActionListener(new ActionListener(){
						public void actionPerformed(ActionEvent ev){
							dispose();
							Stock st=new Stock();
							st.setVisible(true);
							
						}
					});
					pn.add(btactu);
	}
	 private void init2(){
	 		table2=new JTable();
	 		scroll2=new JScrollPane();
	 		scroll2.setBounds(20,200,850,250);
	 		scroll2.setViewportView(table2);
	 		
	 	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Stock st=new Stock();
st.setVisible(true);
	}

}
