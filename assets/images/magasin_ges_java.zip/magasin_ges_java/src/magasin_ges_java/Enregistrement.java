package magasin_ges_java;
/*Code Java SE �crit du 24 au 26 Avril 2021 � N'djam�na au Tchad par TARGOTO Christian
 * Contact: 23560316682 / ct@chrislink.net */
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Enregistrement extends JFrame {
	Statement st;
	Conneccion con=new Conneccion();
	ResultSet rst;
	JTable table,table2,table3;
	JScrollPane scroll,scroll2,scroll3;
	JLabel lbtitre1,lbnom,lbqte,lbdate_exp,lbnumag,lbnature;
	JTextField tfnom,tfqte,tfdate_exp,tfnumag,tfid;
	JComboBox combonature;
	JButton btenrg,btsupp,btstock_mag_prod,btstock_mag_prod_date,btstock;
     public Enregistrement(){
    	 this.setTitle("chcode_appli");
 		this.setSize(1000,600);
 		this.setLocationRelativeTo(null);
 		this.setResizable(false);
 		JPanel pn=new JPanel();
 		pn.setLayout(null);
 		add(pn);
 		pn.setBackground(new Color(150,200,240));
 		
 		lbtitre1=new JLabel("Formulaire d'enregistrement des d�p�ts et retraits de produits");
		lbtitre1.setBounds(50,10,800,30);
		lbtitre1.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbtitre1);
		
		//nom produit
		lbnom=new JLabel("Nom produit");
		lbnom.setBounds(63,60,200,25);
		lbnom.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnom);
						
		tfnom=new JTextField();
		tfnom.setBounds(200,60,150,25);
		pn.add(tfnom);
		//quantit� produit
		lbqte=new JLabel("Quantit� produit");
		lbqte.setBounds(63,90,200,25);
		lbqte.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbqte);
						
		tfqte=new JTextField();
		tfqte.setBounds(200,90,150,25);
		pn.add(tfqte);
		//date expiration
		lbdate_exp=new JLabel("Date expiration");
		lbdate_exp.setBounds(63,120,200,25);
		lbdate_exp.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbdate_exp);
						
		tfdate_exp=new JTextField();
		tfdate_exp.setBounds(200,120,150,25);
		pn.add(tfdate_exp);
		//num�ro magasin
		lbnumag=new JLabel("Num�ro magasin");
		lbnumag.setBounds(63,150,200,25);
		lbnumag.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnumag);
						
		tfnumag=new JTextField();
		tfnumag.setBounds(200,150,150,25);
		pn.add(tfnumag);
		//nature action
				lbnature=new JLabel("Nature action");
				lbnature.setBounds(63,180,200,25);
				lbnature.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbnature);
								
				combonature=new JComboBox();
				combonature.addItem("");
				combonature.addItem("DEPOT");
				combonature.addItem("RETRAIT");
				combonature.setBounds(200,180,150,25);
				pn.add(combonature);
				//id action
				tfid=new JTextField("ID");
				tfid.setBounds(40,230,80,25);
				pn.add(tfid);
		
		
				
		//bouton pour enregistrer les depots et retraits de produits
				btenrg=new JButton("ENREGISTRER");
				btenrg.setBounds(280,230,130,25);
				btenrg.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String nom=tfnom.getText(),
								qte=tfqte.getText(),
								date_exp=tfdate_exp.getText(),
								numag=tfnumag.getText(),
								nature=combonature.getSelectedItem().toString();
			String kk="insert into tb_action(nom_prod,qte_prod,date_exp,date_action,mag_num,nature_action) values('"+nom+"','"+qte+"','"+date_exp+"',now(),'"+numag+"','"+nature+"')";
			        try{
			        	st=con.laConnection().createStatement();
						if(!nom.equals("")&&!qte.equals("")&&!date_exp.equals("")&&!numag.equals("")&&!nature.equals("")){
							st.executeUpdate(kk);
							JOptionPane.showMessageDialog(null,"Enregistrement �ffectu� avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);	
						}
						else{
							JOptionPane.showMessageDialog(null,"Completez le formulaire!",null,JOptionPane.ERROR_MESSAGE);
						}
			        	
			        }
			        catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
				    }
			        dispose();
			        Enregistrement en=new Enregistrement();
			        en.setVisible(true);
					}
				});
				pn.add(btenrg);
		//bouton pour supprimer les depots et retraits de produits
				btsupp=new JButton("SUPPRIMER");
				btsupp.setBounds(130,230,130,25);
				btsupp.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						
					}
				});
				btsupp.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						//v�rifier le num�ro dans la base de donn�es
						String id=tfid.getText(),nb="";
						String req="select count(*) as nb from tb_action where id_action='"+id+"'";
						try{
							st=con.laConnection().createStatement();
							rst=st.executeQuery(req);
							if(rst.next()){
								nb=rst.getString("nb");
							}
						}
						catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
					    }
						//
						String rq="delete from tb_action where id_action='"+id+"'";
						try{
							st=con.laConnection().createStatement();
							if(!id.equals("")){
								if(!nb.equals("0")){
							st.executeUpdate(rq);
							JOptionPane.showMessageDialog(null,"Suppr�ssion �ffectu�e avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
								}
								else{
									JOptionPane.showMessageDialog(null,"Cet enregistrement n'existe pas dans la base de donn�es !",null,JOptionPane.ERROR_MESSAGE);
								}
							}
							else{
								JOptionPane.showMessageDialog(null,"Indiquez l'identifiant du client!",null,JOptionPane.ERROR_MESSAGE);
							}
						}
						catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
					    }
						dispose();
					Enregistrement en=new Enregistrement();
						en.setVisible(true);
					}
					
				});
				pn.add(btsupp);
				//bouton pour acceder � la fenetre de v�rification de stock
				btstock=new JButton("VERIFIER LE STOCK");
				btstock.setBounds(450,230,160,25);
				btstock.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						Stock stk=new Stock();
						stk.setVisible(true);
						
						
					}
				});
				pn.add(btstock);
				//liste des actions
				 DefaultTableModel df2=new  DefaultTableModel();
				  init2();
				  pn.add(scroll2);
				 df2.addColumn("Nom produit");
				 df2.addColumn("Quantit�");
				 df2.addColumn("Date expiration");
				 df2.addColumn("Num�ro magasin");
				 df2.addColumn("Nature action");
				 df2.addColumn("Date action");
				 df2.addColumn("ID action");
				 table2.setModel(df2);
				 String req2="select * from tb_action ORDER by id_action desc";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(req2);
					 while(rst.next()){
						 df2.addRow(new Object[]{
		rst.getString("nom_prod"),rst.getString("qte_prod"),rst.getString("date_exp"),rst.getString("mag_num"),
		rst.getString("nature_action"),rst.getString("date_action"),rst.getString("id_action")
		
								 });
						 
					 }
					 
						 
					 }
					 
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
		
    	 
     }
     private void init2(){
 		table2=new JTable();
 		scroll2=new JScrollPane();
 		scroll2.setBounds(20,280,950,270);
 		scroll2.setViewportView(table2);
 		
 	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Enregistrement en=new Enregistrement();
  en.setVisible(true);
	}

}
