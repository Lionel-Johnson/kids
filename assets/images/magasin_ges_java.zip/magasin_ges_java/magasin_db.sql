-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Mer 28 Avril 2021 à 17:08
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `magasin_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `tb_action`
--

CREATE TABLE IF NOT EXISTS `tb_action` (
  `id_action` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom_prod` varchar(150) NOT NULL,
  `qte_prod` int(11) NOT NULL,
  `date_exp` varchar(50) NOT NULL,
  `date_action` datetime NOT NULL,
  `mag_num` int(11) NOT NULL,
  `nature_action` varchar(50) NOT NULL,
  PRIMARY KEY (`id_action`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `tb_action`
--

INSERT INTO `tb_action` (`id_action`, `nom_prod`, `qte_prod`, `date_exp`, `date_action`, `mag_num`, `nature_action`) VALUES
(1, 'SUCRE EN PAQUET', 4800, '18/11/2022', '2021-04-24 07:53:58', 1, 'DEPOT'),
(3, 'HUILE EN BIDON DE 25L', 180, '10/05/2022', '2021-04-24 08:53:33', 1, 'DEPOT'),
(4, 'RIZ SAC DE 50 KG', 220, '12/06/2024', '2021-04-24 08:54:57', 1, 'DEPOT'),
(5, 'FARINE DE BLE SAC DE 50 KG', 300, '05/09/2023', '2021-04-24 08:57:03', 2, 'DEPOT'),
(6, 'SUCRE EN POUDRE SAC DE 25 KG', 370, '19/11/2023', '2021-04-24 08:58:57', 2, 'DEPOT'),
(7, 'SUCRE EN PAQUET', 230, '22/11/2023', '2021-04-24 09:00:23', 2, 'DEPOT'),
(8, 'SUCRE EN PAQUET', 70, '18/11/2022', '2021-04-24 09:30:51', 1, 'RETRAIT'),
(9, 'SUCRE EN PAQUET', 30, '18/11/2022', '2021-04-24 09:43:00', 1, 'DEPOT');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_stock1`
--
CREATE TABLE IF NOT EXISTS `v_stock1` (
`nom_prod` varchar(150)
,`qte_prod` bigint(20)
,`mag_num` int(11)
,`nature_action` varchar(50)
,`date_exp` varchar(50)
);
-- --------------------------------------------------------

--
-- Structure de la vue `v_stock1`
--
DROP TABLE IF EXISTS `v_stock1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_stock1` AS select `tb_action`.`nom_prod` AS `nom_prod`,`tb_action`.`qte_prod` AS `qte_prod`,`tb_action`.`mag_num` AS `mag_num`,`tb_action`.`nature_action` AS `nature_action`,`tb_action`.`date_exp` AS `date_exp` from `tb_action` where (`tb_action`.`nature_action` = 'DEPOT') union select `tb_action`.`nom_prod` AS `nom_prod`,-(`tb_action`.`qte_prod`) AS `qte_prod`,`tb_action`.`mag_num` AS `mag_num`,`tb_action`.`nature_action` AS `nature_action`,`tb_action`.`date_exp` AS `date_exp` from `tb_action` where (`tb_action`.`nature_action` = 'RETRAIT');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
