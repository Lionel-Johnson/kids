package inscription_ges_java;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Frais extends JFrame {
	Statement st;
	Conneccion con=new Conneccion();
	ResultSet rst;
	JTable table,table2;
	JScrollPane scroll,scroll2;
	JLabel lbtitre1,lbtitre2,lbclasse,lbmontant,lbmatricule;
	JTextField tfmontant,tfmatricule;
	JComboBox comboclasse;
	JButton btenregistrer,btmodif,btrech;
	public Frais(){
		this.setTitle("chcode_appli");
		this.setSize(700,600);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		pn.setBackground(new Color(200,240,200));
		//titre1
		lbtitre1=new JLabel("Formulaire de mise � jour des frais de scolarit�");
		lbtitre1.setBounds(50,10,500,30);
		lbtitre1.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(lbtitre1);
		//titre2
		lbtitre1=new JLabel("Historique des paiements �ffectu�s");
		lbtitre1.setBounds(50,260,500,30);
		lbtitre1.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(lbtitre1);
		//matricule
		lbmatricule=new JLabel("Matricule");
		lbmatricule.setBounds(50,290,120,30);
		lbmatricule.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmatricule);
		
		tfmatricule=new JTextField();
		tfmatricule.setBounds(130,290,120,25);
		pn.add(tfmatricule);
		
		btrech=new JButton("CHERCHER");
		btrech.setBounds(250,290,100,25);
		btrech.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
			String matricule=tfmatricule.getText();
				 DefaultTableModel df2=new  DefaultTableModel();
				 init2();
				  pn.add(scroll2);
				 df2.addColumn("Matricule");
				 df2.addColumn("Date");
				 df2.addColumn("Montant pay� (cfa)");
				df2.addColumn("Nom");
				 df2.addColumn("Pr�nom");
				 df2.addColumn("Classe");
				 table2.setModel(df2);
				 String rq2="select tbHistoriquePaie.matricule,tbHistoriquePaie.datePaie,tbHistoriquePaie.montant"
						 +",prenom,nom,classe"
				 		+ " from tbHistoriquePaie inner join tb_eleve on tb_eleve.matricule=tbHistoriquePaie.matricule "
				 		+ "where tbHistoriquePaie.matricule='"+matricule+"'"
				 		+ " order by tbHistoriquePaie.datePaie desc ";
				 		
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq2);
					 while(rst.next()){
						 df2.addRow(new Object[]{
	rst.getString("matricule"),rst.getString("datePaie"),rst.getString("montant"),rst.getString("prenom")
	,rst.getString("nom"),rst.getString("classe")
															 });
					 }
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
				    }	
				
			}
		});
		pn.add(btrech);
		
		//Classe
				lbclasse=new JLabel("Classe");
				lbclasse.setBounds(27,60,150,25);
				lbclasse.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbclasse);
				
				comboclasse=new JComboBox();
				comboclasse.addItem("6eme");
				comboclasse.addItem("5eme");
				comboclasse.addItem("4eme");
				comboclasse.addItem("3eme");
				comboclasse.addItem("2nde L");
				comboclasse.addItem("2dne S");
				comboclasse.addItem("1ere L");
				comboclasse.addItem("1ere S");
				comboclasse.addItem("TA");
				comboclasse.addItem("TD");
				comboclasse.addItem("TC");
				comboclasse.setBounds(100,60,150,25);
				
				pn.add(comboclasse);
		//montant
				lbmontant=new JLabel("Montant");
				lbmontant.setBounds(27,90,150,25);
				lbmontant.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbmontant);
				
				tfmontant=new JTextField();
				tfmontant.setBounds(100,90,150,25);
				pn.add(tfmontant);
				//bouton enregistrer
				btenregistrer=new JButton("ENREGISTRER");
				btenregistrer.setBounds(100,130,120,25);
				btenregistrer.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String classe=comboclasse.getSelectedItem().toString(),montant=tfmontant.getText();
						String rq="insert into tb_frais(classe,montant) values('"+classe+"','"+montant+"') ";
						try{
							st=con.laConnection().createStatement();
							st.executeUpdate(rq);
					JOptionPane.showMessageDialog(null,"Enregistrement �ffectu� avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
							
						}
						catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
					    }
						dispose();
						Frais fr=new Frais();
						fr.setVisible(true);
						
					}
				});
				pn.add(btenregistrer);
				//bouton modifier
				btmodif=new JButton("MODIFIER");
				btmodif.setBounds(100,170,120,25);
				btmodif.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String classe=comboclasse.getSelectedItem().toString(),montant=tfmontant.getText();
						String rq="update tb_frais set montant='"+montant+"' where classe='"+classe+"' ";
						try{
							st=con.laConnection().createStatement();
							st.executeUpdate(rq);
					JOptionPane.showMessageDialog(null,"Modification �ffectu�e avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
							
						}
						catch(SQLException ex){
					    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
					    }
						dispose();
						Frais fr=new Frais();
						fr.setVisible(true);
						
					}
				});
				pn.add(btmodif);
				//////////table des montants annuels par classe
				DefaultTableModel df=new  DefaultTableModel();
				 init();
				  pn.add(scroll);
				 df.addColumn("Classe");
				 df.addColumn("Montant en cfa");
				 table.setModel(df);
				 String rq="select * from tb_frais";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq);
					 while(rst.next()){
						 df.addRow(new Object[]{
									rst.getString("classe"),rst.getString("montant")
															 });
					 }
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
				    }
				////////table des historiques de paiements
				 DefaultTableModel df2=new  DefaultTableModel();
				 init2();
				  pn.add(scroll2);
				 df2.addColumn("Matricule");
				 df2.addColumn("Date");
				 df2.addColumn("Montant pay� (cfa)");
				df2.addColumn("Nom");
				 df2.addColumn("Pr�nom");
				 df2.addColumn("Classe");
				 table2.setModel(df2);
				 String rq2="select tbHistoriquePaie.matricule,tbHistoriquePaie.datePaie,tbHistoriquePaie.montant"
						 +",prenom,nom,classe"
				 		+ " from tbHistoriquePaie inner join tb_eleve on tb_eleve.matricule=tbHistoriquePaie.matricule "
				 		+ "order by tbHistoriquePaie.datePaie desc ";
				 		
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq2);
					 while(rst.next()){
						 df2.addRow(new Object[]{
	rst.getString("matricule"),rst.getString("datePaie"),rst.getString("montant"),rst.getString("prenom")
	,rst.getString("nom"),rst.getString("classe")
															 });
					 }
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 ///////
				 
				
	}
	//
			private void init(){
				table=new JTable();
				scroll=new JScrollPane();
				scroll.setBounds(300,50,360,200);
				scroll.setViewportView(table);
				
			}
			//
			private void init2(){
				table2=new JTable();
				scroll2=new JScrollPane();
				scroll2.setBounds(20,330,640,210);
				scroll2.setViewportView(table2);
				
			}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Frais fr=new Frais();
		fr.setVisible(true);
		/*Ce code Java SE est �crit du 14 au 22 Mars 2021 � N'djam�na au Tchad par
		 * TARGOTO CHRISTIAN
		 * Contact: ct@chrislink.net / 23560316682*/
	}

}
