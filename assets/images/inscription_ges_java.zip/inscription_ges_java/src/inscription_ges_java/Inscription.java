/*Ce code Java SE est �crit du 14 au 22 Mars 2021 � N'djam�na au Tchad par
 * TARGOTO CHRISTIAN
 * Contact: ct@chrislink.net / 23560316682*/
package inscription_ges_java;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Inscription extends JFrame {
	Statement st;
	Conneccion con=new Conneccion();
	ResultSet rst;
	JTable table;
	JScrollPane scroll;
	JLabel lbtitre,lbtitre2,lbprenom,lbnom,lbsexe,lbdateNaissance,lbclasse,lbquartier,lbcontact,lbsituationClasse,
	lbsituationEcole,lbmatricule,lbmontantPaye,lbmontantAnnuel,lbmontantAnnuel2,lbmpaye,lbmpaye2,
	lbmrestant,lbmrestant2,lbtotalEleves,lbtotalNouveaux,lbnombrEleves,lbnombreFilles,lbnombreGar�ons;
	JTextField tfprenom,tfnom,tfdateNaissance,tfnationalite,tfquartier,tfcontact,tfmatricule,
	tfmontantPaye,tfpaye,tfmontantAnnuel;
	JComboBox combosexe,comboclasse,combosituationClasse,combosituationEcole;
	JButton btenregistrer,btmodifier,btsupprimer,btrech,btajout,btliste,btfrais,btnombre,btnouveau;
	public Inscription(){
		this.setTitle("chcode_appli");
		this.setSize(900,700);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		pn.setBackground(new Color(200,240,200));
		
		lbtitre=new JLabel("Formulaire d'inscripion des �l�ves");
		lbtitre.setBounds(50,10,400,30);
		lbtitre.setFont(new Font("Arial",Font.BOLD,22));
		pn.add(lbtitre);
		//Matricule
		lbmatricule=new JLabel("Matricule");
		lbmatricule.setBounds(63,50,170,25);
		lbmatricule.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmatricule);
				
		tfmatricule=new JTextField();
		tfmatricule.setBounds(143,50,100,25);
		pn.add(tfmatricule);
	
		//prenom
		lbprenom=new JLabel("Pr�nom");
		lbprenom.setBounds(120,90,100,25);
		lbprenom.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbprenom);
		
		tfprenom=new JTextField();
		tfprenom.setBounds(200,90,150,25);
		pn.add(tfprenom);
		//nom
		lbnom=new JLabel("Nom");
		lbnom.setBounds(140,120,100,25);
		lbnom.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnom);
		
		tfnom=new JTextField();
		tfnom.setBounds(200,120,150,25);
		pn.add(tfnom);
		//sexe
		lbsexe=new JLabel("Sexe");
		lbsexe.setBounds(140,150,100,25);
		lbsexe.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbsexe);
		
		combosexe=new JComboBox();
		combosexe.addItem("MASCULIN");
		combosexe.addItem("FEMININ");
		combosexe.setBounds(200,150,150,25);
		pn.add(combosexe);
		
		//date de naissance
		lbdateNaissance=new JLabel("Date de naissance");
		lbdateNaissance.setBounds(40,180,150,25);
		lbdateNaissance.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbdateNaissance);
		
		tfdateNaissance=new JTextField();
		tfdateNaissance.setBounds(200,180,150,25);
		pn.add(tfdateNaissance);
		
		//Classe
		lbclasse=new JLabel("Classe");
		lbclasse.setBounds(127,210,150,25);
		lbclasse.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbclasse);
		
		comboclasse=new JComboBox();
		comboclasse.addItem("6eme");
		comboclasse.addItem("5eme");
		comboclasse.addItem("4eme");
		comboclasse.addItem("3eme");
		comboclasse.addItem("2nde L");
		comboclasse.addItem("2dne S");
		comboclasse.addItem("1ere L");
		comboclasse.addItem("1ere S");
		comboclasse.addItem("TA");
		comboclasse.addItem("TD");
		comboclasse.addItem("TC");
		comboclasse.setBounds(200,210,150,25);
		
		pn.add(comboclasse);
		
		//Quartier
		lbquartier=new JLabel("Quartier");
		lbquartier.setBounds(118,240,150,25);
		lbquartier.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbquartier);
		
		tfquartier=new JTextField();
		tfquartier.setBounds(200,240,150,25);
		pn.add(tfquartier);
		
		//Contact du tuteur
		lbcontact=new JLabel("Contact du tuteur");
		lbcontact.setBounds(47,270,150,25);
		lbcontact.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbcontact);
		
		tfcontact=new JTextField();
		tfcontact.setBounds(200,270,150,25);
		pn.add(tfcontact);
		//Situation dans la classe
		lbsituationClasse=new JLabel("Situation en classe");
		lbsituationClasse.setBounds(40,300,150,25);
		lbsituationClasse.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbsituationClasse);
		
		combosituationClasse=new JComboBox();
		combosituationClasse.addItem("NOUVEAU/NOUVELLE");
		combosituationClasse.addItem("REDOUBLANT(E)");
		combosituationClasse.setBounds(200,300,150,25);
		pn.add(combosituationClasse);
		
		//Situation dans l'�cole
		lbsituationEcole=new JLabel("Situation dans l'�cole");
		lbsituationEcole.setBounds(20,330,170,25);
		lbsituationEcole.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbsituationEcole);
		
		combosituationEcole=new JComboBox();
		combosituationEcole.addItem("ANCIEN(NE)");
		combosituationEcole.addItem("NOUVEAU/NOUVELLE");
		combosituationEcole.setBounds(200,330,150,25);
		pn.add(combosituationEcole);
		//Montant annuel
		lbmontantAnnuel=new JLabel("Montant annuel");
		lbmontantAnnuel.setBounds(60,360,170,25);
		lbmontantAnnuel.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmontantAnnuel);
		
		lbmontantAnnuel2=new JLabel("Montant annuel");
		lbmontantAnnuel2.setBounds(200,360,150,25);
		lbmontantAnnuel2.setFont(new Font("Arial",Font.BOLD,16));
		lbmontantAnnuel2.setForeground(Color.blue);
		pn.add(lbmontantAnnuel2);
		
		//Montant pay� total
		lbmpaye=new JLabel("Montant pay�");
		lbmpaye.setBounds(72,390,170,25);
		lbmpaye.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmpaye);
		
		lbmpaye2=new JLabel("Montant pay�");
		lbmpaye2.setBounds(200,390,170,25);
		lbmpaye2.setFont(new Font("Arial",Font.BOLD,16));
		lbmpaye2.setForeground(new Color(50,120,50));
		pn.add(lbmpaye2);
		//montant restant
		lbmrestant=new JLabel("Montant restant");
		lbmrestant.setBounds(59,420,170,25);
		lbmrestant.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmrestant);
		
		lbmrestant2=new JLabel("Montant restant");
		lbmrestant2.setBounds(200,420,170,25);
		lbmrestant2.setFont(new Font("Arial",Font.BOLD,16));
		lbmrestant2.setForeground(new Color(150,50,50));
		pn.add(lbmrestant2);
		//titre2

		lbtitre2=new JLabel("Formulaire d'enregistrement des paiements");
		lbtitre2.setBounds(20,490,400,30);
		lbtitre2.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbtitre2);
		
		//Montant pay�
		lbmontantPaye=new JLabel("Montant pay�");
		lbmontantPaye.setBounds(20,530,150,25);
		lbmontantPaye.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbmontantPaye);
		
		tfmontantPaye=new JTextField();
		tfmontantPaye.setBounds(130,530,100,25);
		pn.add(tfmontantPaye);
		//bouton recherche matricule
		btrech=new JButton("CHERCHER");
		btrech.setBounds(245,50,100,25);
		btrech.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				String matricule,prenom,nom,sexe,dateN,classe,quartier,contact,s_ecole,s_classe,mt_annuel;
				matricule=tfmatricule.getText();
				prenom=tfprenom.getText();nom=tfnom.getText();
				sexe=combosexe.getSelectedItem().toString();
				dateN=tfdateNaissance.getText();
				classe=comboclasse.getSelectedItem().toString();
				quartier=tfquartier.getText();
				contact=tfcontact.getText();
				s_ecole=combosituationEcole.getSelectedItem().toString();
				s_classe=combosituationClasse.getSelectedItem().toString();
				//mt_annuel=tfmontantAnnuel.getText();
			String rq="select * from frais_eleve where matricule='"+matricule+"'";
			try{
				st=con.laConnection().createStatement();
				rst=st.executeQuery(rq);
				if(rst.next()){
					
					tfprenom.setText(rst.getString("prenom"));
					tfnom.setText(rst.getString("nom"));
					combosexe.setSelectedItem(rst.getString("sexe"));
					tfdateNaissance.setText(rst.getString("dateNaissance"));
					comboclasse.setSelectedItem(rst.getString("classe"));
					tfquartier.setText(rst.getString("quartier"));
					tfcontact.setText(rst.getString("contacTuteur"));
					combosituationClasse.setSelectedItem(rst.getString("situation_classe"));
					combosituationEcole.setSelectedItem(rst.getString("situation_ecole"));
					lbmontantAnnuel2.setText(rst.getString("montant")+" CFA");
					lbmpaye2.setText(rst.getString("montantPaye")+" CFA");
					
					
					
				}
				else{
					JOptionPane.showMessageDialog(null,"Enregistrement inexistant!",null,JOptionPane.ERROR_MESSAGE);
				}
						
				
			}
			catch(SQLException ex){
		    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
		    }
			String rq2="select montant-montantPaye as reste from frais_eleve where matricule='"+matricule+"'";
			try{
				st=con.laConnection().createStatement();
				rst=st.executeQuery(rq2);
				if(rst.next()){
					lbmrestant2.setText(rst.getString("reste")+" CFA");
				}
				
			}
			catch(SQLException ex){
		    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
		    }
			}
			
		});
		pn.add(btrech);
		
		//bouton ajout montant
		btajout=new JButton("AJOUTER");
		btajout.setBounds(130,560,100,25);
		btajout.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				String mtpaye=tfmontantPaye.getText(),matricule=tfmatricule.getText();
				String rq="update tb_eleve set montantPaye=montantPaye+'"+mtpaye+"' where matricule='"+matricule+"' ";
				String rq2="insert into tbHistoriquePaie(matricule,datePaie,montant)"
						+ "values('"+matricule+"',now(),'"+mtpaye+"')";
				try{
					st=con.laConnection().createStatement();
					st.executeUpdate(rq);
					st.executeUpdate(rq2);
					JOptionPane.showMessageDialog(null,"Paiement enregistr� avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
					tfmontantPaye.setText("");
				}
				catch(SQLException ex){
			    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
			    }
				
			}
		});
		pn.add(btajout);
		
		//bouton d'affichage des  effectifs
		btliste=new JButton("AFFICHER LES EFFECTIFS PAR CATEGORIE");
		btliste.setBounds(480,20,340,25);
		btliste.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				Effectif eff=new Effectif();
				eff.setVisible(true);
				
			}
		});
		pn.add(btliste);
		
		//label qui affiche le nombre total des �l�ves d'une classe
		lbnombrEleves=new JLabel("");
		lbnombrEleves.setBounds(420,580,400,25);
		lbnombrEleves.setFont(new Font("Arial",Font.BOLD,16));
		lbnombrEleves.setForeground(Color.BLUE);
		pn.add(lbnombrEleves);
		//label qui affiche le nombre total des filles dans une classe
		lbnombreFilles=new JLabel("");
		lbnombreFilles.setBounds(420,600,400,25);
		lbnombreFilles.setFont(new Font("Arial",Font.BOLD,16));
		lbnombreFilles.setForeground(Color.BLUE);
		pn.add(lbnombreFilles);
		//label qui affiche le nombre total des gar�ons dans une classe
				lbnombreGar�ons=new JLabel("");
				lbnombreGar�ons.setBounds(420,620,400,25);
				lbnombreGar�ons.setFont(new Font("Arial",Font.BOLD,16));
				lbnombreGar�ons.setForeground(Color.BLUE);
				pn.add(lbnombreGar�ons);
		//bouton pour afficher la liste des �l�ves d'une classe
		btliste=new JButton("AFFICHER LA LISTE DES ELEVES D'UNE CLASSE");
		btliste.setBounds(480,60,340,25);
		btliste.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				 DefaultTableModel df=new  DefaultTableModel();
				  init();
				  pn.add(scroll);
				 df.addColumn("Matricule");
				 df.addColumn("Nom");
				 df.addColumn("Pr�nom");
				 df.addColumn("Sexe");
				 df.addColumn("Classe");
				 table.setModel(df);
				 String classe=comboclasse.getSelectedItem().toString(),sexe=combosexe.getSelectedItem().toString();
				 String rq="select * from tb_eleve where classe='"+classe+"'";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq);
					 while(rst.next()){
						 df.addRow(new Object[]{
		rst.getString("matricule"),rst.getString("nom"),rst.getString("prenom"),rst.getString("sexe"),rst.getString("classe")
								 });
						 
					 }
					 
						 
					 }
					 
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 //effectif total
				 String rq2="select count(*) as nbre from tb_eleve where classe='"+classe+"'";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq2);
					 if(rst.next()){
						 lbnombrEleves.setText("Nombre total des �l�ves = "+rst.getString("nbre"));
					 }
					 
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 //nbre filles
				 String rq3="select count(*) as nbre2 from tb_eleve where classe='"+classe+"' and sexe='FEMININ'";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq3);
					 if(rst.next()){
						 lbnombreFilles.setText("Nombre total des filles = "+rst.getString("nbre2"));
					 }
					 
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 //nbre gar�ons
				 String rq4="select count(*) as nbre2 from tb_eleve where classe='"+classe+"' and sexe='MASCULIN'";
				 try{
					 st=con.laConnection().createStatement();
					 rst=st.executeQuery(rq4);
					 if(rst.next()){
						 lbnombreGar�ons.setText("Nombre total des gar�ons = "+rst.getString("nbre2"));
					 }
					 
					 
				 }
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
			}
			
		});
		pn.add(btliste);
		//bouton pour renouveller l'interface graphique
		btnouveau=new JButton("NOUVEAU");
		btnouveau.setBounds(270,540,100,25);
		btnouveau.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				dispose();
				Inscription ins=new Inscription();
				ins.setVisible(true);
			}
			
		});
		pn.add(btnouveau);
		//bouton pour ouvrir l'interface de mis � jour des frais de scolarit�
		btfrais=new JButton("FRAIS SCOLAIRES");
		btfrais.setBounds(20,630,300,25);
		btfrais.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				Frais fr=new Frais();
				fr.setVisible(true);
				
			}
		});
		pn.add(btfrais);
		
		//boutons
		//bouton ajout
		btenregistrer=new JButton("ENREGISTRER");
		btenregistrer.setBounds(20,460,120,25);
		btenregistrer.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				String matricule,prenom,nom,sexe,dateN,classe,quartier,contact,s_ecole,s_classe;
				matricule=tfmatricule.getText();
				prenom=tfprenom.getText();nom=tfnom.getText();
				sexe=combosexe.getSelectedItem().toString();
				dateN=tfdateNaissance.getText();
				classe=comboclasse.getSelectedItem().toString();
				quartier=tfquartier.getText();
				contact=tfcontact.getText();
				s_ecole=combosituationEcole.getSelectedItem().toString();
				s_classe=combosituationClasse.getSelectedItem().toString();
				
		String rq1="insert into tb_eleve(matricule,prenom,nom,sexe,dateNaissance,classe,quartier,contacTuteur,situation_classe,situation_ecole,montantPaye)"
				+ "values('"+matricule+"','"+prenom+"','"+nom+"','"+sexe+"','"+dateN+"','"+classe+"','"+quartier+"','"+contact+"','"+s_classe+"','"+s_ecole+"','0.00')";
		try{
			st=con.laConnection().createStatement();
			if(!matricule.equals("")&&!prenom.equals("")&&!nom.equals("")&&!dateN.equals("")&&!quartier.equals("")&&!contact.equals("")){
			st.executeUpdate(rq1);
    		JOptionPane.showMessageDialog(null,"Insertion reussie!",null,JOptionPane.INFORMATION_MESSAGE);
			}
			else{
				JOptionPane.showMessageDialog(null,"Completez le formulaire!",null,JOptionPane.ERROR_MESSAGE);
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
					
			}
		});
		pn.add(btenregistrer); 
		//bouton modifier
		btmodifier=new JButton("MODIFIER");
		btmodifier.setBounds(150,460,100,25);
		btmodifier.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				String matricule,prenom,nom,sexe,dateN,classe,quartier,contact,s_ecole,s_classe;
				matricule=tfmatricule.getText();
				prenom=tfprenom.getText();nom=tfnom.getText();
				sexe=combosexe.getSelectedItem().toString();
				dateN=tfdateNaissance.getText();
				classe=comboclasse.getSelectedItem().toString();
				quartier=tfquartier.getText();
				contact=tfcontact.getText();
				s_ecole=combosituationEcole.getSelectedItem().toString();
				s_classe=combosituationClasse.getSelectedItem().toString();
				String rq="update tb_eleve set prenom='"+prenom+"',nom='"+nom+"',sexe='"+sexe+"',dateNaissance='"+dateN+"',"
				+ "classe='"+classe+"', quartier='"+quartier+"', contacTuteur='"+contact+"',situation_classe='"+s_classe+"',"
								+ "situation_ecole='"+s_ecole+"'     where matricule='"+matricule+"'";
				try{
					st=con.laConnection().createStatement();
					st.executeUpdate(rq);
					JOptionPane.showMessageDialog(null,"Modification �ffectu�e avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
					
				}
				catch(SQLException ex){
			    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
			    }
			}
		});
		pn.add(btmodifier); 
		//bouton supprimer
		btsupprimer=new JButton("SUPPRIMER");
		btsupprimer.setBounds(260,460,110,25);
		btsupprimer.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				String matricule=tfmatricule.getText();
				String rq="delete from tb_eleve where matricule='"+matricule+"'";
				try{
					st=con.laConnection().createStatement();
					if(!matricule.equals("")){
						if(JOptionPane.showConfirmDialog(null,"voulez vous Supprimer? ",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
							st.executeUpdate(rq);
							JOptionPane.showMessageDialog(null,"Suppr�ssion �ffectu�e avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);
						}
					}
					else{
						JOptionPane.showMessageDialog(null,"Indiquez d'abord le num�ro de matricule !",null,JOptionPane.ERROR_MESSAGE);
					}
				}
				catch(SQLException ex){
			    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
			    }
			
		}
		});
		pn.add(btsupprimer); 
			
	}
	//la methode d'initiation du tableau
		private void init(){
			table=new JTable();
			scroll=new JScrollPane();
			scroll.setBounds(400,100,460,470);
			scroll.setViewportView(table);
			
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Inscription ins=new Inscription();
  ins.setVisible(true);
  /*Ce code Java SE est �crit du 14 au 22 Mars 2021 � N'djam�na au Tchad par
   * TARGOTO CHRISTIAN
   * Contact: ct@chrislink.net / 23560316682*/
	}

}
