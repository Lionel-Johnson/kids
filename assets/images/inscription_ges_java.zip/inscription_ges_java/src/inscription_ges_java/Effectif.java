package inscription_ges_java;

import java.awt.Color;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Effectif extends JFrame {
	Statement st;
	Conneccion con=new Conneccion();
	ResultSet rst;
	JLabel lbtotal,lbfilles,lbgar�ons,lbnouveaux,lbanciens;
	public Effectif(){
		this.setTitle("chcode_appli");
		this.setSize(450,250);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		pn.setBackground(new Color(200,240,200));
		
		//nombre total des eleves
		lbtotal=new JLabel("Nombre total des �l�ves :");
		lbtotal.setBounds(20,20,300,30);
		lbtotal.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbtotal);
		
		String rq="select count(matricule) as total from tb_eleve";
		try{
			st=con.laConnection().createStatement();
			rst=st.executeQuery(rq);
			if(rst.next()){
			lbtotal.setText("Nombre total des �l�ves = "+rst.getString("total"));	
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		//Nombre total des gar�ons
		lbgar�ons=new JLabel("Nombre total des gar�ons :");
		lbgar�ons.setBounds(20,50,300,30);
		lbgar�ons.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbgar�ons);
		
		String rq2="select count(matricule) as nbgars from tb_eleve where sexe='MASCULIN'";
		try{
			st=con.laConnection().createStatement();
			rst=st.executeQuery(rq2);
			if(rst.next()){
			lbgar�ons.setText("Nombre total des gar�ons = "+rst.getString("nbgars"));	
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		//Nombre total des filles
		lbfilles=new JLabel("Nombre total des filles :");
		lbfilles.setBounds(20,80,300,30);
		lbfilles.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbfilles);
		
		String rq3="select count(matricule) as nbfilles from tb_eleve where sexe='FEMININ'";
		try{
			st=con.laConnection().createStatement();
			rst=st.executeQuery(rq3);
			if(rst.next()){
				lbfilles.setText("Nombre total des filles = "+rst.getString("nbfilles"));	
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		//Nombre total des anciens
		lbanciens=new JLabel("Nombre total des anciens �l�ves :");
		lbanciens.setBounds(20,110,400,30);
		lbanciens.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbanciens);
		
		String rq4="select count(matricule) as nb_anciens from tb_eleve where situation_ecole='ANCIEN(NE)'";
		try{
			st=con.laConnection().createStatement();
			rst=st.executeQuery(rq4);
			if(rst.next()){
				lbanciens.setText("Nombre total des anciens �l�ves = "+rst.getString("nb_anciens"));	
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		//Nombre total des nouveaux
		lbnouveaux=new JLabel("Nombre total des nouveaux �l�ves :");
		lbnouveaux.setBounds(20,140,400,30);
		lbnouveaux.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbnouveaux);
		
		String rq5="select count(matricule) as nb_nouveaux from tb_eleve where situation_ecole='NOUVEAU/NOUVELLE'";
		try{
			st=con.laConnection().createStatement();
			rst=st.executeQuery(rq5);
			if(rst.next()){
				lbnouveaux.setText("Nombre total des nouveaux �l�ves = "+rst.getString("nb_nouveaux"));	
			}
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Effectif ef=new Effectif();
		ef.setVisible(true);
		/*Ce code Java SE est �crit du 14 au 22 Mars 2021 � N'djam�na au Tchad par
		 * TARGOTO CHRISTIAN
		 * Contact: ct@chrislink.net / 23560316682*/
	}

}
