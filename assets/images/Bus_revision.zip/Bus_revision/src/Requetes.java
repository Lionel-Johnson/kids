import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Requetes extends JFrame {
	JTable tb1,tb2;
	JScrollPane scrl1,scrl2;
	Statement st;
	ResultSet rst;
	Connectage cn=new Connectage();
	JLabel titre,titre2,lbnum,lbdate;
	JTextField tfnum,tfdate;
	JButton btadd,btsupp,btbus;
	public Requetes(){
		this.setTitle("chcode_appli");
		this.setSize(600,570);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		pn.setBackground(new Color(150,180,250));
		
		titre=new JLabel("Liste des bus dont le d�lai de revision a expir� ");
		titre.setBounds(15,20,450,30);
		titre.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(titre);
		
		titre2=new JLabel("Liste des bus dont le d�lai de revision expire dans moins d'une semaine ");
		titre2.setBounds(15,290,550,30);
		titre2.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(titre2);
		
		////
		DefaultTableModel df=new DefaultTableModel();
		init();
		df.addColumn("Matricule");
		df.addColumn("Date derni�re r�vision");
		
		tb1.setModel(df);
		pn.add(scrl1);
		//r�vision techniques des bus chaque 60 jours
		String sql="select * from bus where datediff(now(),date_revi1)>60";
		
	 cn=new Connectage();
		try{
			st=cn.laconnexion().createStatement();
			rst=st.executeQuery(sql);
			while(rst.next()){
		df.addRow(new Object[]{
				rst.getString("matricule"),
				rst.getString("date_revi1")		
		});
			}
		}
		catch(SQLException ex){
			
		}
		///
		
		////
				DefaultTableModel df2=new DefaultTableModel();
				init2();
				df2.addColumn("Matricule");
				df2.addColumn("Date derni�re r�vision");
				
				tb2.setModel(df2);
				pn.add(scrl2);
				//rappel une semaine d'avance
				String sql2="select * from bus where datediff(now(),date_revi1)>53 and datediff(now(),date_revi1)<60";
				
			 cn=new Connectage();
				try{
					st=cn.laconnexion().createStatement();
					rst=st.executeQuery(sql2);
					while(rst.next()){
				df2.addRow(new Object[]{
						rst.getString("matricule"),
						rst.getString("date_revi1")		
				});
					}
				}
				catch(SQLException ex){
					
				}
				///
				btbus=new JButton("Bus");
				btbus.setBounds(15,490,100,25);
				btbus.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						dispose();
						Bus bs=new Bus();
						bs.setVisible(true);
						
					}
				});
				pn.add(btbus);
	}
	private void init(){
		tb1=new JTable();
		scrl1=new JScrollPane();
		scrl1.setViewportView(tb1);
		scrl1.setBounds(15,60,510,210);
	}
	
	private void init2(){
		tb2=new JTable();
		scrl2=new JScrollPane();
		scrl2.setViewportView(tb2);
		scrl2.setBounds(15,330,510,150);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Requetes rq=new Requetes();
		rq.setVisible(true);

	}

}
