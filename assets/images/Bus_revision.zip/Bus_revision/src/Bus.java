import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Bus extends JFrame {
	JTable tb1;
	JScrollPane scrl1;
	Statement st;
	ResultSet rst;
	Connectage cn=new Connectage();
	JLabel titre,lbnum,lbdate;
	JTextField tfnum,tfdate;
	JButton btadd,btmodif,btsupp,btreq;
	public Bus(){
		this.setTitle("chcode_appli");
		this.setSize(580,500);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		pn.setBackground(new Color(150,180,250));
		
		titre=new JLabel("Mise � jour de la derni�re r�vision technique de chaque bus");
		titre.setBounds(40,20,500,30);
		titre.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(titre);
		
		lbnum=new JLabel("Num�ro de matricule");
		lbnum.setBounds(63,60,200,25);
		lbnum.setFont(new Font("Arial",Font.BOLD,15));
		pn.add(lbnum);
		
		tfnum=new JTextField();
		tfnum.setBounds(250,60,100,25);
		pn.add(tfnum);
		
		lbdate=new JLabel("Date r�vision");
		lbdate.setBounds(116,100,200,25);
		lbdate.setFont(new Font("Arial",Font.BOLD,15));
		pn.add(lbdate);
		
		tfdate=new JTextField();
		tfdate.setBounds(250,100,100,25);
		pn.add(tfdate);
		
		//boutons
				btadd=new JButton("Enregistrer");
				btadd.setBounds(105,160,100,25);
				btadd.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						String a=tfnum.getText(),
								b=tfdate.getText();
								
								
		String sql="insert into bus(matricule,date_revi1) values('"+a+"','"+b+"')";
		           try{
		        	   st=cn.laconnexion().createStatement();
		        	   st.executeUpdate(sql);
		        	   JOptionPane.showMessageDialog(null,"Ajout r�ussi !");
		        	   dispose();
		        	   Bus bs=new Bus();
		        	   bs.setVisible(true);
		           }
		           catch(SQLException ex){
		        	 JOptionPane.showMessageDialog(null,"Impossible d'ajouter !",null,JOptionPane.ERROR_MESSAGE);  
		           }
						
					}
				});
				pn.add(btadd);
				
				btmodif=new JButton("Modifier");
				btmodif.setBounds(235,160,100,25);
				btmodif.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						String a=tfnum.getText(),b=tfdate.getText();
														
		String sql="update bus set date_revi1='"+b+"' where matricule='"+a+"'";
		           try{
		        	   st=cn.laconnexion().createStatement();
		        	   if(JOptionPane.showConfirmDialog(null,"Voulez-vous modifier ?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
		        		   st.executeUpdate(sql);
		            	   JOptionPane.showMessageDialog(null,"Modification r�ussie !");
		            	   dispose();
		            	   Bus bs=new Bus();
		            	   bs.setVisible(true);  
		        	   }
		        	  
		           }
		           catch(SQLException ex){
		        	 JOptionPane.showMessageDialog(null,"Impossible de modifier !",null,JOptionPane.ERROR_MESSAGE);  
		           }
						
					}
				});
				pn.add(btmodif);
				btsupp=new JButton("Supprimer");
				btsupp.setBounds(355,160,100,25);
				btsupp.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						String a=tfnum.getText();
								
								
		String sql="delete from bus where matricule='"+a+"' ";
		           try{
		        	   st=cn.laconnexion().createStatement();
		        	   if(JOptionPane.showConfirmDialog(null,"Voulez-vous supprimer ?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
		        		   st.executeUpdate(sql);
		            	   JOptionPane.showMessageDialog(null,"Suppr�ssion r�ussie !");
		            	   dispose();
		            	   Bus bs=new Bus();
		            	   bs.setVisible(true);  
		        	   }
		        	  
		           }
		           catch(SQLException ex){
		        	 JOptionPane.showMessageDialog(null,"Impossible de supprimer !",null,JOptionPane.ERROR_MESSAGE);  
		           }
						
					}
				});
				pn.add(btsupp);
			    btreq=new JButton("Requetes");
				btreq.setBounds(375,100,100,25);
				btreq.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						dispose();
						Requetes rq=new Requetes();
						rq.setVisible(true);
						
					}
				});
				pn.add(btreq);
				////
				DefaultTableModel df=new DefaultTableModel();
				init();
				df.addColumn("Matricule");
				df.addColumn("Date r�vision1");
				
				tb1.setModel(df);
				pn.add(scrl1);
				
				String sql="select * from bus";
				
			 cn=new Connectage();
				try{
					st=cn.laconnexion().createStatement();
					rst=st.executeQuery(sql);
					while(rst.next()){
				df.addRow(new Object[]{
						rst.getString("matricule"),
						rst.getString("date_revi1")		
				});
					}
				}
				catch(SQLException ex){
					
				}
				///
	}
	private void init(){
		tb1=new JTable();
		scrl1=new JScrollPane();
		scrl1.setViewportView(tb1);
		scrl1.setBounds(45,210,460,210);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bus bs=new Bus();
		bs.setVisible(true);

	}

}
