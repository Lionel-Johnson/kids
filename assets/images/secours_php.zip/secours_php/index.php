<?php 
/*Code php écrit du 11 au 12 Mai 2021 à N'djaména au Tchad par
   TARGOTO Christian
   Contact: ct@chrislink.net / 23560316682
 */
?>
<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "secours_db";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
} 

?>

<?php 
$mess1="";
$mess2="";
$id=@$_POST["id"];
$nom=@$_POST["nom"];
$age=@$_POST["age"];
$sexe=@$_POST["sexe"];
$s_eco=@$_POST["s_eco"];
$s_sante=@$_POST["s_sante"];

$id_resp=@$_POST["id_resp"];
$id_mbre=@$_POST["id_mbre"];
$nom_mbre=@$_POST["nom_mbre"];
$age_mbre=@$_POST["age_mbre"];
$sexe_mbre=@$_POST["sexe_mbre"];
$s_sante_mbre=@$_POST["s_sante_mbre"];

?>
<?php 
//enregistrement des individus
if(isset($_POST['benrg'])&&!empty($id)&&!empty($nom)&&!empty($age)&&!empty($sexe)&&!empty($s_eco)&&!empty($s_sante)){
$sql=mysqli_query($conn,"insert into tb_individu(id,nom,age,sexe,economie,sante) values('$id','$nom','$age','$sexe','$s_eco','$s_sante')");
  if($sql){
 $mess1="<b>Enregistrement effectué avec succes !</b>";
}
else{
 $mess1="<b>Erreur !</b>";
}
}
?>
<?php 
//enregistrement des membres de familles
if(isset($_POST['benrg2'])&&!empty($id_resp)){
$sql=mysqli_query($conn,"insert into tb_famille(id_membre,nom_m,age_m,sexe_m,sante_m,id_chef) values('$id_mbre','$nom_mbre','$age_mbre','$sexe_mbre','$s_sante_mbre','$id_resp')");
  if($sql){
 $mess2="<b>Enregistrement éffectué avec succès !</b>";
}
else{
 $mess2="<b>Erreur !</b>";
}
}
?>
<?php 
//Suppréssion d'un individu
if(isset($_POST['bsupp'])&&!empty($id)){
$sql=mysqli_query($conn,"delete from tb_individu where id='$id'");
  if($sql){
 $mess1="<b>Suppréssion éffectuée avec succès !</b>";
}
else{
 $mess1="<b>Erreur !</b>";
}
}
?>
<?php 
//Suppréssion membre d'une famille
if(isset($_POST['bsupp2'])&&!empty($id_mbre)){
$sql=mysqli_query($conn,"delete from tb_famille where id_membre='$id_mbre'");
  if($sql){
 $mess2="<b>Suppréssion éffectuée avec succès !</b>";
}
else{
 $mess2="<b>Erreur !</b>";
}
}
?>
<?php 
//modifier les renseignements sur individu
if(isset($_POST['bmodif'])&&!empty($id)){
  //update nom
  if(!empty($nom)){
  mysqli_query($conn,"update tb_individu set nom='$nom' where id='$id'");
  }
  //update age
  if(!empty($age)){
  mysqli_query($conn,"update tb_individu set age='$age' where id='$id'");
  }
  //update sexe
  if(!empty($sexe)){
  mysqli_query($conn,"update tb_individu set sexe='$sexe' where id='$id'");
  }
  //update economie
  if(!empty($s_eco)){
  mysqli_query($conn,"update tb_individu set economie='$s_eco' where id='$id'");
  }
  //update santé
  if(!empty($s_sante)){
  mysqli_query($conn,"update tb_individu set sante='$s_sante' where id='$id'");
  }
   $mess1="<b>Modification éffectuée avec succès!</b>";
}
?>
<?php 
//modifier les renseignements sur membre d'une famille
if(isset($_POST['bmodif2'])&&!empty($id_mbre)){
  //update nom
  if(!empty($nom_mbre)){
  mysqli_query($conn,"update tb_famille set nom_m='$nom_mbre' where id_membre='$id_mbre'");
  }
  //update age
  if(!empty($age_mbre)){
  mysqli_query($conn,"update tb_famille set age_m='$age_mbre' where id_membre='$id_mbre'");
  }
  //update sexe
  if(!empty($sexe_mbre)){
  mysqli_query($conn,"update tb_famille set sexe_m='$sexe_mbre' where id_membre='$id_mbre'");
  }
  //update responsable
  if(!empty($id_resp)){
  mysqli_query($conn,"update tb_famille set id_chef='$id_resp' where id_membre='$id_mbre'");
  }
  //update santé
  if(!empty($s_sante_mbre)){
  mysqli_query($conn,"update tb_famille set sante_m='$s_sante_mbre' where id_membre='$id_mbre'");
  }
   $mess2="<b>Modification éffectuée avec succès!</b>";
}
?>
<?php 
//actualiser la page
if(isset($_POST['bactu'])){
}
?>
<!-- Created by TopStyle Trial - www.topstyle4.com -->
<!DOCTYPE html>
<html>
<head>
	<title>chcode_appli</title>
	<meta charset="utf8">
	<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>

<body>
	<div align="center">
	<br>
<a href="requetes.php"><b>ALLER DANS LA PAGE DES REQUETES</b></a>
<br><br>
<form action="" method="POST">
      <table>
      <tr><td></td><td><input type="submit" name="liste1" value="Afficher la liste des individus" class="bouton4"></td></tr>
      <tr><td></td><td><input type="submit" name="liste2" value="Afficher la liste des membres de familles" class="bouton4" ></td></tr>
      <tr><td></td><td><input type="submit" name="bactu" value="Actualiser" class="bouton4" ></td></tr>
      </table>
      </form>
       <?php 
//affichage de la liste des individus enregistrés
if(isset($_POST['liste1'])){
print"<h3>Liste des individus</h3>";
	$rq2=mysqli_query($conn,"select * from tb_individu order by id desc");
	print'<table border="1" class="tab"><tr><th>Identifiant</th><th>Nom</th><th>Age</th><th>Sexe</th><th>Economie</th><th>Santé</th></tr>';
	
	while($rst2=mysqli_fetch_assoc($rq2)){
	         print"<tr>";
	         echo"<td>".$rst2['id']."</td>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	        echo"<td>".$rst2['economie']."</td>";
	        echo"<td>".$rst2['sante']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
<?php 
//affichage de la liste des membres de familles enregistrés
if(isset($_POST['liste2'])){
print"<h3>Liste des membres de familles</h3>";
	$rq2=mysqli_query($conn,"select * from tb_famille order by id_membre desc");
	print'<table border="1" class="tab"><tr><th>ID responsable</th><th>ID membre</th><th>Nom</th><th>Age</th><th>Sexe</th><th>Santé</th></tr>';
	
	while($rst2=mysqli_fetch_assoc($rq2)){
	         print"<tr>";
	         echo"<td>".$rst2['id_chef']."</td>";
	         echo"<td>".$rst2['id_membre']."</td>";
	          echo"<td>".$rst2['nom_m']."</td>";
	         echo"<td>".$rst2['age_m']."</td>";
	         echo"<td>".$rst2['sexe_m']."</td>";
	        echo"<td>".$rst2['sante_m']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
	<h2>Formulaire d'enregistrement des individus</h2>
    <form action="" method="POST">
      <fieldset>
      <legend ><b>INDIVIDU</b></legend>
      <table>
      <tr><td><b>Identifiant </b></td><td><input type="text"  name="id" value="<?php print $id;?>"></td><td><input type="submit" name="brech" value="CHERCHER" class="bouton"></td></tr>
      <tr><td><b>Nom </b></td><td><input type="text"  name="nom" value=""></td><td></td></tr>
      <tr><td><b>Age</b></td><td><input type="number" name="age" min="0" value=""></td></tr>
      <tr><td><b>Sexe</b></td><td><select name="sexe" id="sexe"  >
	<option  value="<?php echo $sexe; ?>"><?php echo $sexe; ?></option>
	      <option  value="FEMININ">FEMININ</option>
         <option  value="MASCULIN">MASCULIN</option>
     </select></td></tr>
      
       <tr><td><b>Situation économique</b></td><td><select name="s_eco" id="s_eco"  >
	<option  value="<?php echo $s_eco; ?>"><?php echo $s_eco; ?></option>
	      <option  value="SATISFAISANT">SATISFAISANT</option>
         <option  value="VULNERABLE">VULNERABLE</option>
     </select></td></tr>
     
     <tr><td><b>Etat de santé</b></td><td><select name="s_sante" id="s_sante"  >
	<option  value="<?php echo $s_sante; ?>"><?php echo $s_sante; ?></option>
	      <option  value="BIEN">BIEN</option>
         <option  value="FRAGILE">FRAGILE</option>
         <option  value="MALADE">MALADE</option>
     </select></td></tr>
      <tr><td></td><td><input type="submit" name="benrg" value="ENREGISTRER" class="bouton"></td></tr>
      <tr><td></td><td><input type="submit" name="bmodif" value="MODIFIER" class="bouton"></td></tr>
      <tr><td></td><td><input type="submit" name="bsupp" value="SUPPRIMER" class="bouton"></td></tr>
      <tr><td></td><td><?php print $mess1;?></td></tr>
      </table>
      </fieldset>
      </form>
      <?php 
//afficher les renseignements sur un individu
if(isset($_POST['brech'])){
$nb=0;
//verifier si il ou elle a une famille
$sq=mysqli_query($conn,"select count(*) as nb from tb_famille where id_chef='$id'");
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}

print"<h3>Renseignement sur un individu</h3>";
	$rq2=mysqli_query($conn,"select * from tb_individu where id='$id'");
	print'<table border="1" class="tab"><tr><th>Identifiant</th><th>Nom</th><th>Age</th><th>Sexe</th><th>Economie</th><th>Santé</th></tr>';
	
	if($rst2=mysqli_fetch_assoc($rq2)){
	         print"<tr>";
	         echo"<td>".$rst2['id']."</td>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	        echo"<td>".$rst2['economie']."</td>";
	        echo"<td>".$rst2['sante']."</td>";
	         print"</tr>";
	}
	print'</table>';
	
	if($nb>0){
	print"<h3>Les membres de sa famille</h3>";
	$rq3=mysqli_query($conn,"select * from tb_famille where id_chef='$id'");
	print'<table border="1" class="tab"><tr><th>ID chef</th><th>ID membre</th><th>Nom</th><th>Age</th><th>Sexe</th><th>Santé</th></tr>';
	
	while($rst3=mysqli_fetch_assoc($rq3)){
	         print"<tr>";
	         echo"<td>".$rst3['id_chef']."</td>";
	         echo"<td>".$rst3['id_membre']."</td>";
	          echo"<td>".$rst3['nom_m']."</td>";
	         echo"<td>".$rst3['age_m']."</td>";
	         echo"<td>".$rst3['sexe_m']."</td>";
	        echo"<td>".$rst3['sante_m']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
}
?>
      
      <h2>Formulaire d'enregistrement des membres d'une famille</h2>
    <form action="" method="POST">
      <fieldset>
      <legend ><b>MEMBRE</b></legend>
      <table>
      <tr><td><b>ID responsable </b></td><td><input type="text"  name="id_resp" value=""></td><td></td></tr>
      <tr><td><b>ID membre </b></td><td><input type="text"  name="id_mbre" value="<?php print $id_mbre;?>"></td><td><input type="submit" name="brech2" value="CHERCHER" class="bouton"></td></tr>
      <tr><td><b>Nom </b></td><td><input type="text"  name="nom_mbre" value=""></td><td></td></tr>
      <tr><td><b>Age</b></td><td><input type="number" name="age_mbre" min="0" value=""></td></tr>
      <tr><td><b>Sexe</b></td><td><select name="sexe_mbre" id="sexe_mbre"  >
	<option  value="<?php echo $sexe_mbre; ?>"><?php echo $sexe_mbre; ?></option>
	      <option  value="FEMININ">FEMININ</option>
         <option  value="MASCULIN">MASCULIN</option>
     </select></td></tr>
     
     <tr><td><b>Etat de santé</b></td><td><select name="s_sante_mbre" id="s_sante_mbre"  >
	<option  value="<?php echo $s_sante_mbre; ?>"><?php echo $s_sante_mbre; ?></option>
	      <option  value="BIEN">BIEN</option>
         <option  value="FRAGILE">FRAGILE</option>
         <option  value="MALADE">MALADE</option>
     </select></td></tr>
      <tr><td></td><td><input type="submit" name="benrg2" value="ENREGISTRER" class="bouton"></td></tr>
      <tr><td></td><td><input type="submit" name="bmodif2" value="MODIFIER" class="bouton"></td></tr>
      <tr><td></td><td><input type="submit" name="bsupp2" value="SUPPRIMER" class="bouton"></td></tr>
      <tr><td></td><td><?php print $mess2;?></td></tr>
      </table>
      </fieldset>
      </form>
       <?php 
//afficher les renseignements sur un membre d'une famille
if(isset($_POST['brech2'])){
$idresp='';
print"<h3>Renseignement sur un membre d'une famille</h3>";
	$rq2=mysqli_query($conn,"select * from tb_famille where id_membre='$id_mbre'");
	print'<table border="1" class="tab"><tr><th>ID membre</th><th>ID chef</th><th>Nom membre</th><th>Age membre</th><th>Sexe membre</th><th>Santé membre</th></tr>';
	
	if($rst2=mysqli_fetch_assoc($rq2)){
	$idresp=$rst2['id_chef'];
	         print"<tr>";
	         echo"<td>".$rst2['id_membre']."</td>";
	         echo"<td>".$rst2['id_chef']."</td>";
	          echo"<td>".$rst2['nom_m']."</td>";
	         echo"<td>".$rst2['age_m']."</td>";
	         echo"<td>".$rst2['sexe_m']."</td>";
	        echo"<td>".$rst2['sante_m']."</td>";
	         print"</tr>";
	}
	print'</table>';
	
	print"<h3>Renseignement  sur le responsable de la famille</h3>";
	$rq3=mysqli_query($conn,"select * from tb_individu where id='$idresp'");
	print'<table border="1" class="tab"><tr><th>ID responsable</th><th>Nom</th><th>Age</th><th>Sexe</th><th>Economie</th><th>Santé</th></tr>';
	
	while($rst3=mysqli_fetch_assoc($rq3)){
	         print"<tr>";
	         echo"<td>".$rst3['id']."</td>";
	          echo"<td>".$rst3['nom']."</td>";
	         echo"<td>".$rst3['age']."</td>";
	         echo"<td>".$rst3['sexe']."</td>";
	         echo"<td>".$rst3['economie']."</td>";
	        echo"<td>".$rst3['sante']."</td>";
	         print"</tr>";
	}
	print'</table>';

}
/*Code php écrit du 11 au 12 Mai 2021 à N'djaména au Tchad par
   TARGOTO Christian
   Contact: ct@chrislink.net / 23560316682
 */
?>
      
     

	<br><br>
	</div>
</body>
</html>