-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 07 Mai 2021 à 14:37
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `secours_db`
--

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `population`
--
CREATE TABLE IF NOT EXISTS `population` (
`nom` varchar(150)
,`age` smallint(6)
,`sexe` varchar(15)
,`sante` varchar(15)
);
-- --------------------------------------------------------

--
-- Structure de la table `tb_famille`
--

CREATE TABLE IF NOT EXISTS `tb_famille` (
  `id_membre` int(11) NOT NULL,
  `nom_m` varchar(150) NOT NULL,
  `age_m` smallint(6) NOT NULL,
  `sexe_m` varchar(15) NOT NULL,
  `sante_m` varchar(15) NOT NULL,
  `id_chef` int(11) NOT NULL,
  PRIMARY KEY (`id_membre`),
  KEY `fk` (`id_chef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tb_famille`
--

INSERT INTO `tb_famille` (`id_membre`, `nom_m`, `age_m`, `sexe_m`, `sante_m`, `id_chef`) VALUES
(1001, 'ZENABA OUSMANE ', 12, 'FEMININ', 'BIEN', 1),
(1002, 'BRAHIM OUSMANE ', 8, 'MASCULIN', 'FRAGILE', 1),
(1003, 'SERGE NDOUNDO', 5, 'MASCULIN', 'BIEN', 3),
(1004, 'ALICE TOGBE', 2, 'FEMININ', 'FRAGILE', 3);

-- --------------------------------------------------------

--
-- Structure de la table `tb_individu`
--

CREATE TABLE IF NOT EXISTS `tb_individu` (
  `id` int(11) NOT NULL,
  `nom` varchar(150) NOT NULL,
  `age` smallint(6) NOT NULL,
  `sexe` varchar(15) NOT NULL,
  `economie` varchar(15) NOT NULL,
  `sante` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tb_individu`
--

INSERT INTO `tb_individu` (`id`, `nom`, `age`, `sexe`, `economie`, `sante`) VALUES
(1, 'ALI OUSMANE BRAHIM', 49, 'MASCULIN', 'VULNERABLE', 'FRAGILE'),
(2, 'BOUBOU  HAMIDOU', 37, 'MASCULIN', 'VULNERABLE', 'BIEN'),
(3, 'ANAIS NETOL', 32, 'FEMININ', 'VULNERABLE', 'BIEN'),
(4, 'YOUSSOUF DJIBRILA', 71, 'MASCULIN', 'VULNERABLE', 'FRAGILE'),
(5, 'DENDOLOUM ESTHER', 68, 'FEMININ', 'VULNERABLE', 'MALADE'),
(6, 'ALFRED ERNESTO', 22, 'MASCULIN', 'VULNERABLE', 'BIEN');

-- --------------------------------------------------------

--
-- Structure de la vue `population`
--
DROP TABLE IF EXISTS `population`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `population` AS select `tb_individu`.`nom` AS `nom`,`tb_individu`.`age` AS `age`,`tb_individu`.`sexe` AS `sexe`,`tb_individu`.`sante` AS `sante` from `tb_individu` union select `tb_famille`.`nom_m` AS `nom`,`tb_famille`.`age_m` AS `age`,`tb_famille`.`sexe_m` AS `sexe`,`tb_famille`.`sante_m` AS `sante` from `tb_famille`;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `tb_famille`
--
ALTER TABLE `tb_famille`
  ADD CONSTRAINT `fk` FOREIGN KEY (`id_chef`) REFERENCES `tb_individu` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
