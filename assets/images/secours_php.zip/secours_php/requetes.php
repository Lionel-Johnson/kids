<?php 
/*Code php écrit du 11 au 12 Mai 2021 à N'djaména au Tchad par
   TARGOTO Christian
   Contact: ct@chrislink.net / 23560316682
 */
?>
<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "secours_db";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
} 

?>
<?php 
$sexe=@$_POST["sexe"];
$etat=@$_POST["etat"];
?>
<!-- Created by TopStyle Trial - www.topstyle4.com -->
<!DOCTYPE html>
<html>
<head>
	<title>chcode_appli</title>
	<meta charset="utf8">
	<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>

<body>
	<div align="center">
		<br>
<a href="index.php"><b>ALLER DANS LA PAGE DES ENREGISTREMENTS</b></a>
<h2>Affichage de la liste et du nombre de la population par catégorie</h2>
<form action="" method="POST">
<table>
 <tr><td><b>Sexe</b></td><td><select name="sexe" id="sexe"  >
	<option  value=""></option>
         <option  value="FEMININ">FEMININ</option>
         <option  value="MASCULIN">MASCULIN</option>
     </select></td><td><input type="submit" name="b18plus" value="Plus de 18 ans" class="bouton"></td></tr>
     <tr><td></td><td></td><td><input type="submit" name="b65plus" value="Plus de 65 ans" class="bouton"></td></tr>
     <tr><td></td><td></td><td><input type="submit" name="b6moins" value="Moins de 6 ans" class="bouton"></td></tr>
     <tr><td></td><td></td><td><input type="submit" name="b6_24" value="De 6 à 24 ans" class="bouton"></td></tr>
     
     <tr><td><b>Etat de santé</b></td><td><select name="etat" id="etat"  >
     <option  value="<?php print $etat;?>"><?php print $etat;?></option>
         <option  value="BIEN">BIEN</option>
         <option  value="FRAGILE">FRAGILE</option>
         <option  value="MALADE">MALADE</option>
     </select></td><td><input type="submit" name="b_etat" value="Trouver" class="bouton"></td></tr>
</table>
</form>
 <?php 
//affichage de la catégorie de la population ayant plus de 18 ans
if(isset($_POST['b18plus'])){
print"<h3>Liste de la catégorie de la population</h3>";
//nombre de la catégorie
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>18");
	if(!empty($sexe)){
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>18 and sexe='$sexe'");
	}
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<b>Nombre total : $nb</b><br><br>";
//liste de la catégorie
	$rq1=mysqli_query($conn,"select * from population where age>18");
	if(!empty($sexe)){
	$rq1=mysqli_query($conn,"select * from population where age>18 and sexe='$sexe'");
	}
	print'<table border="1" class="tab"><tr><th>Nom</th><th>Age</th><th>Sexe</th></tr>';
	while($rst2=mysqli_fetch_assoc($rq1)){
	         print"<tr>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
 <?php 
//affichage de la catégorie de la population ayant plus de 65 ans
if(isset($_POST['b65plus'])){
print"<h3>Liste de la catégorie de la population</h3>";
//nombre de la catégorie
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>65");
	if(!empty($sexe)){
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>65 and sexe='$sexe'");
	}
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<b>Nombre total : $nb</b><br><br>";
//liste de la catégorie
	$rq1=mysqli_query($conn,"select * from population where age>65");
	if(!empty($sexe)){
	$rq1=mysqli_query($conn,"select * from population where age>65 and sexe='$sexe'");
	}
	print'<table border="1" class="tab"><tr><th>Nom</th><th>Age</th><th>Sexe</th></tr>';
	while($rst2=mysqli_fetch_assoc($rq1)){
	         print"<tr>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
<?php 
//affichage de la catégorie de la population ayant moins de 6 ans
if(isset($_POST['b6moins'])){
print"<h3>Liste de la catégorie de la population</h3>";
//nombre de la catégorie
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population where age<6");
	if(!empty($sexe)){
	$sq=mysqli_query($conn,"select count(*) as nb from population where age<6 and sexe='$sexe'");
	}
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<b>Nombre total : $nb</b><br><br>";
//liste de la catégorie
	$rq1=mysqli_query($conn,"select * from population where age<6");
	if(!empty($sexe)){
	$rq1=mysqli_query($conn,"select * from population where age<6 and sexe='$sexe'");
	}
	print'<table border="1" class="tab"><tr><th>Nom</th><th>Age</th><th>Sexe</th></tr>';
	while($rst2=mysqli_fetch_assoc($rq1)){
	         print"<tr>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
<?php 
//affichage de la catégorie de la population ayant entre 6 et 24 ans
if(isset($_POST['b6_24'])){
print"<h3>Liste de la catégorie de la population</h3>";
//nombre de la catégorie
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>=6 and age<=24");
	if(!empty($sexe)){
	$sq=mysqli_query($conn,"select count(*) as nb from population where age>=6 and age<=24 and sexe='$sexe'");
	}
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<b>Nombre total : $nb</b><br><br>";
//liste de la catégorie
	$rq1=mysqli_query($conn,"select * from population where age>=6 and age<=24");
	if(!empty($sexe)){
	$rq1=mysqli_query($conn,"select * from population where age>=6 and age<=24 and sexe='$sexe'");
	}
	print'<table border="1" class="tab"><tr><th>Nom</th><th>Age</th><th>Sexe</th></tr>';
	while($rst2=mysqli_fetch_assoc($rq1)){
	         print"<tr>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
<?php 
//affichage de la catégorie de la population ayant un meme etat de santé
if(isset($_POST['b_etat'])){
print"<h3>Liste de la catégorie de la population</h3>";
//nombre de la catégorie
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population where sante='$etat'");
	if(!empty($sexe)){
	$sq=mysqli_query($conn,"select count(*) as nb from population where sante='$etat' and sexe='$sexe'");
	}
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<b>Nombre total : $nb</b><br><br>";
//liste de la catégorie
	$rq1=mysqli_query($conn,"select * from population where sante='$etat'");
	if(!empty($sexe)){
	$rq1=mysqli_query($conn,"select * from population where sante='$etat' and sexe='$sexe'");
	}
	print'<table border="1" class="tab"><tr><th>Nom</th><th>Age</th><th>Sexe</th><th>Etat santé</th></tr>';
	while($rst2=mysqli_fetch_assoc($rq1)){
	         print"<tr>";
	          echo"<td>".$rst2['nom']."</td>";
	         echo"<td>".$rst2['age']."</td>";
	         echo"<td>".$rst2['sexe']."</td>";
	          echo"<td>".$rst2['sante']."</td>";
	         print"</tr>";
	}
	print'</table>';
}
?>
<?php 
//nombre total de la population
$nb=0;
	$sq=mysqli_query($conn,"select count(*) as nb from population ");
	
	if($rs=mysqli_fetch_assoc($sq)){
	$nb=$rs['nb'];
	}
echo "<br><b>Nombre total de la population  enregistrée : $nb</b><br><br>";
/*Code php écrit du 11 au 12 Mai 2021 à N'djaména au Tchad par
   TARGOTO Christian
   Contact: ct@chrislink.net / 23560316682
 */
?>
	</div>
</body>
</html>